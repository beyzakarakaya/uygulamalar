import sys
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QWidget,QMainWindow, QTableWidget, QLabel
from PyQt5.QtGui import QPixmap
from elbey import Ui_MainWindow

import sqlite3 as sqlite
import sqlite3 
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem
from PyQt5.uic import loadUi

conn = sqlite.connect('elbey.db')
print("Bağlanti gerçekleştirildi")

cursor = conn.cursor()
print("Cursor olusturuldu")

cursor.execute("""CREATE TABLE IF NOT EXISTS URUNLER
    (MARKA TEXT, 
    ADET INTEGER,
    ADET_FIYATI INTEGER,
    ALINAN_TARIH INTEGER,
    MALZEME_TURU TEXT,
    DEPOLANMA_SEKLI TEXT)""")
print("tablo oluşturuldu")

conn.commit()
conn.close()

class Window(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()

        self.setupUi(self)

        self.label.setPixmap(QPixmap("logo.png"))

  
class MainWindow(QMainWindow):
    def _init_(self):
        super(MainWindow, self)._init_()
        loadUi("elbey.ui", self)  
        self.elbey_data()  

    def elbey_data(self):
        connection = sqlite3.connect("elbey.db")
        cursor = connection.cursor()

       
        query = "SELECT * FROM URUNLER"  
        cursor.execute(query)
        data = cursor.fetchall()


        
        self.tableWidget.setRowCount(len(data))
        self.tableWidget.setColumnCount(len(data[0]))
        rows=cursor.fetchall()

        for satirIndeks, satirVeri in enumerate(rows):
            for sutunIndeks, sutunVeri in enumerate(satirVeri):
                item = QTableWidgetItem(str(sutunVeri))
                self.tableWidget.setItem(satirIndeks, sutunIndeks, item)

        cursor.execute("INSERT INTO URUNLER (MARKA, ADET, FIYAT, TARIH, TUR, DEPOLANMA_SEKLI)")
        connection.commit() 

def main():
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())

if __name__ == "_main_":
    main()


def app():
    app=QtWidgets.QApplication(sys.argv)
    win=Window()
    win.show()
    sys.exit(app.exec_())
app()