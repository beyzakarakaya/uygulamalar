import sys
import enum
from ast import Index
from PyQt5 import QtWidgets 
from PyQt5.QtWidgets import *
from gamze_son import *
from PyQt5.QtGui import QPixmap, QIcon 
from PyQt5 import * 
import sys
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QWidget,QMainWindow, QTableWidgetItem, QMessageBox, QHeaderView
from ast import Index
import enum






uygulama=QApplication(sys.argv)
pencere=QMainWindow()
ui=Ui_MainWindow()
ui.setupUi(pencere)
pencere.show()
ui.label.setPixmap(QPixmap("ustlogo.png"))
ui.label.setScaledContents(True)
# ui.setWindowIcon(QIcon("logo.png"))



import sqlite3
baglanti=sqlite3.connect("yeristas.db")
islem=baglanti.cursor()
baglanti.commit()

tablo=islem.execute("create table if not exists uydu(UYDU_STATUSU text,HATA_KODU text,GONDERME_SAATİ text,BASINC1 int,BASINC2 int,YUKSEKLİK1 int, IRTIFA_FARKI int,INIS_HIZI int,SICAKLIK int,PIL_GERILIMI int,GPS1_LATIDUDE int,GPS1_LONGITUDE int,PITCH int)")
baglanti.commit()



def kayit_ekle():
    HATA_KODU = ui.label_3.text()
    BASINC1=ui.label_5.text()
    BASINC2=ui.label_6.text()
    YUKSEKLİK1=ui.label_7.text()
    GONDERME_SAATİ= ui.timeEdit.time().toString()
    UYDU_STATUSU= ui.lineEdit_8.text()
    
    if (HATA_KODU == "" or BASINC1 == "" or BASINC2 == "" or YUKSEKLİK1 == ""  or GONDERME_SAATİ == ""  or UYDU_STATUSU == "" ):
        ui.statusbar.showMessage("degerler  bos bırakılamaz")
    else:

        try:
            ekle="INSERT INTO uydu(UYDU_STATUSU, HATA_KODU ,GONDERME_SAATİ,BASINC1,BASINC2,YUKSEKLİK1)VALUES(?,?,?,?,?,?)" 
                    
                            
            islem.execute(ekle,(UYDU_STATUSU,HATA_KODU,GONDERME_SAATİ,BASINC1,BASINC2,YUKSEKLİK1))
            baglanti.commit()
            ui.statusbar.showMessage("kayıt yukleme işlemi başarili",2000)
        except Exception as eror:
            ui.statusbar.showMessage("kayıt yuklenemedi"+str(eror)) 

    ui.tableWidget.clear()
    ui.tableWidget.setHorizontalHeaderLabels(("UYDU_STATUSU, HATA_KODU ,GONDERME_SAATİ,BASINC1,BASINC2,YUKSEKLİK1"))
    sorgu = "select * from uydu "
    islem.execute(sorgu)
   
    for indexSatir, kayitNumarasi in enumerate(islem): 
        for indexSutun, kayitSutun in enumerate(kayitNumarasi): 
            ui.tableWidget.setItem(indexSatir,indexSutun,QTableWidgetItem(str(kayitSutun)))



     
    
      

ui.pushButton.clicked.connect(kayit_ekle)

sys.exit(uygulama.exec_())