#from PyQt4 import uic

from PyQt5 import uic

with open('untitled.py', 'w', encoding="utf-8") as fout:
   uic.compileUi('untitled.ui', fout)