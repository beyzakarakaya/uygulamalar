import folium

# latitude, longitude = 38.833333, 33.333333

# my_map = folium.Map(location=[latitude, longitude], zoom_start=12)

# folium.Marker([latitude, longitude], popup='Merkez Noktası').add_to(my_map)

# my_map.save("harita3.html")

harita = folium.Map(location=[41.01,29.015], zoom_start=11,width=550, height=550,)
harita.save("a.html")


