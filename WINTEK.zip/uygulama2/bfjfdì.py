from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QApplication, QMainWindow, QWebEngineView

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # create a QWebEngineView widget
        self.web_view = QWebEngineView(self)
        # load HTML content
        
        self.web_view.setHtml("a.html")
        # set the widget as the main window's central widget
        self.setCentralWidget(self.web_view)
if __name__ == '__main__':
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

    # hata veriyor kütüphanem eksik sanırım